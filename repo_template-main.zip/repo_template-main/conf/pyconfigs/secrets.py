from dataclasses import dataclass, field
from pydantic import SecretStr

import os
from dataclasses import dataclass, field

import mlflow
from mlflow import MlflowClient
from pydantic import SecretStr


from conf.pyconfigs.base_config import BaseConfig

@dataclass(frozen=True, slots=True, kw_only=True)
class DBCredentials(BaseConfig):
    host: str
    username: str
    password: SecretStr = field(repr=False)
    port: int
    

@dataclass(frozen=True, slots=True, kw_only=True)
class MLFlowConfig(BaseConfig):
    tracking_uri: str
    username: str
    password: SecretStr = field(repr=False)
    
    
    def __post_init__(self) -> None:
        os.environ["MLFLOW_TRACKING_URI"] = self.tracking_uri
        os.environ["MLFLOW_TRACKING_USERNAME"] = self.username
        os.environ["MLFLOW_TRACKING_PASSWORD"] = str(self.password)
        os.environ["MLFLOW_TRACKING_INSECURE_TLS"] = "true"
        
        try:
            MlflowClient(self.tracking_uri).search_experiments(max_results=1)
        except Exception as e:
            raise ConnectionError(
                f"MLflow fail: {self.tracking_uri}"
            ) from e


@dataclass(frozen=True, slots=True, kw_only=True)
class MLFlowExp(BaseConfig):
    experiment_name: str
    experiment_id: str
    
    run_name: str
    run_id: str
    
    @classmethod
    def from_name(cls, experiment_name: str, run_name: str):
        assert mlflow.search_experiments(max_results=1) is not None, (
            "Cannot connect to MLflow Tracking Server"
        )
        
        experiment = mlflow.get_experiment_by_name(experiment_name)
        
        if experiment is None:
            experiment_id = mlflow.create_experiment(experiment_name)
        else:
            experiment_id = experiment.experiment_id
            
            
        runs = mlflow.search_runs(
            experiment_ids=[experiment_id],
            filter_string=f"tags.`mlflow.runName` = '{run_name}'",
            output_format="list",
        )
        
        assert len(runs) <= 1, (
            f"Expected at most one run named {run_name!r} "
            f"in experiment {experiment_name!r}, but found {len(runs)}"
        )
        
        if runs:
            run_id = runs[0].info.run_id
        else:
            with mlflow.start_run(
                experiment_id=experiment_id,
                run_name=run_name,
            ) as run:
                run_id = run.info.run_id
        
        return MLFlowExp(
            experiment_name=experiment_name,
            experiment_id=experiment_id,
            run_name=run_name,
            run_id=run_id
        )