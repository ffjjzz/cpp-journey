from dataclasses import dataclass
from conf.pyconfigs.base_config import BaseConfig


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceTable(BaseConfig):
    database: str
    table: str

    @property
    def full_name(self) -> str:
        return f"{self.database}.{self.table}"


@dataclass(frozen=True, slots=True, kw_only=True)
class ProcessDescription(BaseConfig):
    transformers_names: list
    fixed_params: dict


@dataclass(frozen=True, slots=True, kw_only=True)
class ProfilingDescription(BaseConfig):
    profilers_names: list[str]
    params: dict
    

@dataclass(frozen=True, slots=True, kw_only=True)
class OptunaTrainConfig(BaseConfig):
    model_name: str
    optuna_params: dict
    search_space: dict
    fixed_params: dict
    fit_params: dict


@dataclass(frozen=True, slots=True, kw_only=True)
class ValidationConfig(BaseConfig):
    names: list
    params: dict


@dataclass(frozen=True, slots=True, kw_only=True)
class TSValidationConfig(BaseConfig):
    n_splits: int
    gap: int