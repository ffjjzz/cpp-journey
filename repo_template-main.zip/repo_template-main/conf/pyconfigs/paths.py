from dataclasses import dataclass
from pathlib import Path
from conf.pyconfigs.base_config import BaseConfig

class BaseConfigPath(BaseConfig):
    @classmethod
    def from_dict(cls, data: dict):
        path_dict = {key: Path(value) for key, value in data.items()}
        return cls(**path_dict)


@dataclass(frozen=True, slots=True, kw_only=True)
class DataPaths(BaseConfigPath):
    raw: Path
    processed: Path
    
@dataclass(frozen=True, slots=True, kw_only=True)
class ManifestPaths(BaseConfigPath):
    load: Path
    process: Path
    profiling: Path
    train: Path
    eval: Path
    
@dataclass(frozen=True, slots=True, kw_only=True)
class ConfigPath(BaseConfigPath):
    load: Path
    process: Path
    profiling: Path
    train: Path
    eval: Path

@dataclass(frozen=True, slots=True, kw_only=True)
class StatisticsPath(BaseConfigPath):
    profiling: Path
    metrics: Path

@dataclass(frozen=True, slots=True, kw_only=True)
class Paths(BaseConfig):
    data: DataPaths
    manifest: ManifestPaths
    config: ConfigPath
    stats: StatisticsPath

    models: Path
    
    @classmethod
    def from_yaml(cls, path: Path):
        paths_config = cls.read_yaml(path)
        return Paths(
            data=DataPaths.from_dict(paths_config["data"]),
            config=ConfigPath.from_dict(paths_config["config"]),
            manifest=ManifestPaths.from_dict(paths_config["manifest"]),
            stats=StatisticsPath.from_dict(paths_config["statistics"]),
            models=Path(paths_config["models"])
        )
