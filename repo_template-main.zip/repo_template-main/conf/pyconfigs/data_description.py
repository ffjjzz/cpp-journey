from dataclasses import dataclass
from conf.pyconfigs.base_config import BaseConfig


@dataclass(frozen=True, slots=True, kw_only=True)
class RawDataDesc(BaseConfig):
    pi_columns: list[str]
    feature_columns: list[str]
    time_column: str
    
    target_column: str | None
    
    
    def get_config_columns(self) -> list[str]:
        all_columns = set(self.pi_columns + self.feature_columns)
        
        if self.target_column is not None:
            all_columns.add(self.target_column)

        if self.time_column is not None:
            all_columns.add(self.time_column)

        return list(all_columns)


@dataclass(frozen=True, slots=True, kw_only=True)
class ProcessedDataDesc(BaseConfig):
    pi_columns: list[str]
    numeric_columns: list[str]
    category_columns: list[str]
    time_column: str
    target_column: str | None