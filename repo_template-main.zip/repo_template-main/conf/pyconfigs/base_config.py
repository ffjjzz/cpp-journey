from dataclasses import dataclass, fields
from pathlib import Path
import yaml


@dataclass(frozen=True, slots=True, kw_only=True)
class BaseConfig:
    @staticmethod
    def read_yaml(path: Path) -> dict:
        with Path(path).open(encoding="utf-8") as file:
            data = yaml.safe_load(file)

        if not isinstance(data, dict):
            raise ValueError(
                f"Expected a dictionary at the root of YAML file '{path.name}'"
            )
            
        return data
    
    @classmethod
    def filter_dict(cls, data: dict):
        field_names = {field.name for field in fields(cls) if field.init}
        kwargs = {key: value for key, value in data.items() if key in field_names}
        return kwargs

    @classmethod
    def from_dict(cls, data: dict):
        filtered_dict = cls.filter_dict(data)
        return cls(**filtered_dict)
    
    @classmethod
    def from_yaml(cls, path: Path):
        dict_config = cls.read_yaml(path)
        return cls.from_dict(dict_config)