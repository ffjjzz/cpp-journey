from pathlib import Path
import yaml
import mlflow
from dataclasses import asdict

def save_manifest(meta_dict: dict, config_path: Path):
    with config_path.open("w", encoding="utf-8") as file:
        yaml.safe_dump(
            meta_dict,
            file,
            allow_unicode=True,
            sort_keys=False,
        )
        
def load_manifest(config_path: Path):
    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    return config


#####################################################################################
#LOAD
RAW_DATA_PATH_NAME = "raw_data_path"
ML_FLOW_RUN_ID = "mlflow_run_id"
MLFLOW_RAW_ARTIFACT_PATH = "raw"

def save_load_manifest(manifest_path: Path, raw_data_path: Path, mlflow_run_id: str):
    load_manifest = {
        RAW_DATA_PATH_NAME: str(raw_data_path),
        ML_FLOW_RUN_ID: mlflow_run_id
        }
    save_manifest(load_manifest, manifest_path)
    return manifest_path

def parse_load_manifest(load_manifest_path: Path):
    config = load_manifest(load_manifest_path)
    return config[RAW_DATA_PATH_NAME], config[ML_FLOW_RUN_ID]

def log_load_mlflow(mlflow_run_id: str, load_manifest_path: Path):
    with mlflow.start_run(run_id=mlflow_run_id):
        mlflow.log_artifact(local_path=str(load_manifest_path), artifact_path=MLFLOW_RAW_ARTIFACT_PATH)


#####################################################################################
#PROCESS
from conf.pyconfigs import ProcessedDataDesc

PROCESS_DATA_PATH_NAME = "processed_data_path"
ENCODE_MAP_PATH = "encode_map_path"
MLFLOW_RAW_ARTIFACT_PATH = "processed"

def save_process_manifest(
    manifest_path: Path,
    processed_config: ProcessedDataDesc,
    process_state_path: Path,
    processed_data_path: Path,
    mlflow_run_id: str
    ):
    process_manifest = {
        **asdict(processed_config),
        PROCESS_DATA_PATH_NAME: str(processed_data_path),
        ENCODE_MAP_PATH: str(process_state_path),
        ML_FLOW_RUN_ID: mlflow_run_id,
        }
    save_manifest(process_manifest, manifest_path)
    return manifest_path

def parse_process_manifest(process_manifest_path: Path):
    config = load_manifest(process_manifest_path)
    return ProcessedDataDesc.from_dict(config), config[PROCESS_DATA_PATH_NAME], config[ML_FLOW_RUN_ID]

def log_process_mlflow(mlflow_run_id: str, process_manifest_path: Path, encode_map_path: Path):
    with mlflow.start_run(run_id=mlflow_run_id):
        mlflow.log_artifact(local_path=str(process_manifest_path), artifact_path=MLFLOW_RAW_ARTIFACT_PATH)
        mlflow.log_artifact(local_path=str(encode_map_path), artifact_path=MLFLOW_RAW_ARTIFACT_PATH)



################################################################################################
#PROFILING
MLFLOW_PROFILING_ARTIFACT_PATH = "profiling"

def log_profiling_mlflow(mlflow_run_id: str, artifacts_folder: Path):
    with mlflow.start_run(run_id=mlflow_run_id):
        mlflow.log_artifacts(local_dir=str(artifacts_folder), artifact_path=MLFLOW_PROFILING_ARTIFACT_PATH)


################################################################################################
#TRAINING
ML_FLOW_TRAIN_RUN_ID="mlflow_train_run_id"
MLFLOW_MODEL_DIR = ""
LOCAL_MODEL_PATH = "model_path"


def log_train_mlflow(mlflow_run_id: str, model_path: Path):
    with mlflow.start_run(run_id=mlflow_run_id):
        mlflow.log_artifact(str(model_path), artifact_path=MLFLOW_MODEL_DIR)


def save_train_manifest(manifest_path: Path, model_path: Path, mlflow_run_id: str):
    train_manifest = {
        ML_FLOW_TRAIN_RUN_ID: mlflow_run_id,
        LOCAL_MODEL_PATH: str(model_path)
        }
    save_manifest(train_manifest, manifest_path)
    return manifest_path


def parse_train_manifest(train_manifest_path: Path):
    config = load_manifest(train_manifest_path)
    return config[ML_FLOW_TRAIN_RUN_ID], config[LOCAL_MODEL_PATH]