from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field, fields, asdict
from typing import Any, ClassVar, Self, Optional, cast

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline

@dataclass
class BaseTransformer(BaseEstimator, TransformerMixin, ABC):
    registry: ClassVar[dict[str, type[BaseTransformer]]] = {}

    def __init_subclass__(cls, **kw: Any) -> None:
        super().__init_subclass__(**kw)
        BaseTransformer.registry[cls.__name__] = cls

    @property
    def is_fitted(self) -> bool:
        return all(getattr(self, f.name) is not None for f in fields(self))
    
    def __sklearn_is_fitted__(self) -> bool:
        return self.is_fitted
    
    def get_state(self) -> dict[str, Any]:
        return asdict(self)

    def fit(self, X: pd.DataFrame, y: Any = None) -> Self:
        if not self.is_fitted:
            self._fit(X, y)
        return self 
    
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        if not self.is_fitted:
            raise RuntimeError(f"{type(self).__name__} is not fitted")
        return self._transform(X)
    
    @abstractmethod
    def _fit(self, X: pd.DataFrame, y: Any = None) -> Self: ...

    @abstractmethod
    def _transform(self, X: pd.DataFrame) -> pd.DataFrame: ...


@dataclass
class MainTransformer(BaseEstimator, TransformerMixin):
    names: list[str]
    params: dict[str, dict[str, Any]] = field(default_factory=dict)
    pipeline_: Pipeline = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self.pipeline_ = Pipeline([
            (n, BaseTransformer.registry[n](**self.params.get(n, {})))
            for n in self.names
        ])

    def fit(self, X: pd.DataFrame, y: Any = None) -> Self:
        self.pipeline_.fit(X, y)
        return self
    
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        return cast(pd.DataFrame, self.pipeline_.transform(X))

    def get_params_state(self) -> dict[str, dict[str, Any]]:
        return {n: p.get_state() for n, p in self.pipeline_.steps}
    




##########################################################################################################################
@dataclass
class ColumnSelector(BaseTransformer):
    columns: Optional[list[str]] = None

    def _fit(self, X: pd.DataFrame, y: Any = None) -> Self:
        self.columns = X.columns.tolist()
        return self

    def _transform(self, X: pd.DataFrame) -> pd.DataFrame:
        return X[self.columns]#type: ignore

@dataclass
class TimeSorter(BaseTransformer):
    time_column: str
    
    def _fit(self, X: pd.DataFrame, y: Any = None) -> Self:
        return self

    def _transform(self, X: pd.DataFrame) -> pd.DataFrame:
        return X.sort_values(self.time_column, kind="stable")


UNKNOWN_CATEGORY = -1
@dataclass
class CategoricalEncoder(BaseTransformer):
    columns: Optional[list[str]] = None
    encode_map: Optional[dict] = None
    
    def _encode_column(self, column: pd.Series, encode_map: dict):
        return column.map(encode_map).fillna(UNKNOWN_CATEGORY).astype("int64")
    
    def _get_column_map(self, column: pd.Series):
        
        return {value: code for code, value in enumerate(sorted(column.dropna().unique()))}
    
    def _fit(self, X: pd.DataFrame, y: Any = None) -> Self:
        assert self.columns is not None
        self.encode_map={column: self._get_column_map(X[column]) for column in self.columns}
        return self
    
    def _transform(self, X: pd.DataFrame) -> pd.DataFrame:
        assert self.columns is not None and self.encode_map is not None
        for column in self.columns:
            X[column] = self._encode_column(X[column], self.encode_map[column]).astype("category")
        return X