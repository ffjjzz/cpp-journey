from __future__ import annotations

from typing import Any, Sequence, TypeVar, Mapping
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from src.train_tools.metrics import Evaluator
import pandas as pd
from collections.abc import Callable, Iterator, Sequence
from src.train_tools.models import BaseModel
import numpy as np
from sklearn.model_selection import TimeSeriesSplit
import optuna 
from conf.pyconfigs.stage_description import OptunaTrainConfig
import mlflow
from mlflow import MlflowClient


def predict_inputs(
    model: BaseModel,
    X: pd.DataFrame,
    input_types: set[str],
) -> dict[str, Any]:
    methods = {"labels": "predict", "proba": "predict_proba"}
    return {
        name: getattr(model, methods[name])(X)
        for name in input_types
    }


@dataclass
class HoldoutValidator:
    evaluator: Evaluator
    predict_inputs: Callable[
        [BaseModel, pd.DataFrame, set[str]],
        dict[str, Any],
    ] = predict_inputs

    def fit(
        self,
        model: BaseModel,
        X: pd.DataFrame,
        y: pd.Series,
        *,
        cat_features: Sequence[str] | None = None,
        eval_set: tuple[pd.DataFrame, pd.Series] | None = None,
        **fit_kwargs: Any,
    ) -> BaseModel:
        return model.fit(
            X,
            y,
            cat_features=cat_features,
            eval_set=eval_set,
            **fit_kwargs,
        )

    def predict(
        self,
        model: BaseModel,
        X: pd.DataFrame,
    ) -> dict[str, Any]:
        return self.predict_inputs(
            model,
            X,
            self.evaluator.required_input_types(),
        )

    def evaluate(
        self,
        y_true: pd.Series,
        **inputs: Any,
    ) -> dict[str, Any]:
        return self.evaluator.evaluate(y_true, **inputs)

    def run(
        self,
        model: BaseModel,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_valid: pd.DataFrame,
        y_valid: pd.Series,
        *,
        cat_features: Sequence[str] | None = None,
        **fit_kwargs: Any,
    ) -> tuple[BaseModel, dict[str, Any]]:
        model = self.fit(
            model,
            X_train,
            y_train,
            cat_features=cat_features,
            eval_set=(X_valid, y_valid),
            **fit_kwargs,
        )
        inputs = self.predict(model, X_valid)
        scores = self.evaluate(y_valid, **inputs)

        return model, scores

@dataclass
class TimeSeriesValidator:
    validator: HoldoutValidator
    n_splits: int = 5
    gap: int = 0

    def split(
        self,
        X: pd.DataFrame,
    ) -> Iterator[tuple[np.ndarray, np.ndarray]]:
        return TimeSeriesSplit(
            n_splits=self.n_splits,
            gap=self.gap,
        ).split(X)

    def run(
        self,
        model: BaseModel,
        X: pd.DataFrame,
        y: pd.Series,
        *,
        cat_features: Sequence[str] | None = None,
        **fit_kwargs: Any,
    ) -> pd.DataFrame:
        results = []

        for train_idx, valid_idx in self.split(X):
            _, scores = self.validator.run(
                model=model.clone(),
                X_train=X.iloc[train_idx],
                y_train=y.iloc[train_idx],
                X_valid=X.iloc[valid_idx],
                y_valid=y.iloc[valid_idx],
                cat_features=cat_features,
                **fit_kwargs,
            )
            results.append(scores)

        return pd.DataFrame(results)



@dataclass
class OptunaTrainer:
    validator: TimeSeriesValidator
    config: OptunaTrainConfig
    
        
    def on_trial_evaluated(
        self,
        trial: optuna.Trial,
        model_params: dict,
        scores: pd.DataFrame,
        objective_value: float,
    ) -> None:
        pass

    def suggest_params(self, trial: optuna.Trial) -> dict[str, Any]:
        params = {}

        for name, settings in self.config.search_space.items():
            match settings["type"]:
                case "int":
                    params[name] = trial.suggest_int(
                        name,
                        low=settings["low"],
                        high=settings["high"],
                    )
                case "float":
                    params[name] = trial.suggest_float(
                        name,
                        low=settings["low"],
                        high=settings["high"],
                    )
                case "categorical":
                    params[name] = trial.suggest_categorical(
                        name,
                        choices=settings["choices"],
                    )
                case _:
                    raise ValueError(
                        f"Неизвестный тип параметра {name!r}: "
                        f"{settings['type']!r}"
                    )

        return params

    def objective(
        self,
        trial: optuna.Trial,
        model: BaseModel,
        X: pd.DataFrame,
        y: pd.Series,
        *,
        cat_features: Sequence[str] | None = None,
    ) -> float:
        candidate = model.clone()
        candidate.params = {
            **self.config.fixed_params,
            **self.suggest_params(trial),
        }

        scores = self.validator.run(
            model=candidate,
            X=X,
            y=y,
            cat_features=cat_features,
            **self.config.fit_params,
        )

        metric = self.config.optuna_params["metric"]
        objective_value = float(scores[metric].mean())

        self.on_trial_evaluated(
            trial=trial,
            model_params=candidate.params.copy(),
            scores=scores,
            objective_value=objective_value,
        )

        return objective_value



    def run(
        self,
        model: BaseModel,
        X: pd.DataFrame,
        y: pd.Series,
        *,
        cat_features: Sequence[str] | None = None,
    ) -> optuna.Study:
        study = optuna.create_study(
            direction=self.config.optuna_params["direction"],
        )
        study.optimize(
            lambda trial: self.objective(
                trial,
                model,
                X,
                y,
                cat_features=cat_features,
            ),
            n_trials=self.config.optuna_params["n_trials"],
        )
        return study
    




@dataclass
class MlflowOptunaTrainer(OptunaTrainer):
    mlflow_run_id: str
    model_run_id: str = field(init=False)

    def __post_init__(self):
        self.client = MlflowClient()
        parent = self.client.get_run(self.mlflow_run_id)

        self.model_run_id = self.client.create_run(
            experiment_id=parent.info.experiment_id,
            run_name=self.config.model_name,
            tags={"mlflow.parentRunId": self.mlflow_run_id},
        ).info.run_id

    def on_trial_evaluated(
        self, trial, model_params, scores, objective_value
    ):
        parent = self.client.get_run(self.model_run_id)

        run = self.client.create_run(
            experiment_id=parent.info.experiment_id,
            run_name=f"trial_{trial.number}",
            tags={"mlflow.parentRunId": self.model_run_id},
        )

        with mlflow.start_run(run_id=run.info.run_id, nested=True):
            mlflow.log_params(model_params)
            mlflow.log_metric(
                f"mean_{self.config.optuna_params['metric']}",
                objective_value,
            )
            mlflow.log_text(
                scores.to_csv(index=True),
                "metrics_by_split.csv",
            )

    def close(self, status="FINISHED"):
        self.client.set_terminated(self.model_run_id, status=status)
