from __future__ import annotations
from catboost import CatBoostClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from abc import ABC, abstractmethod
from typing import Any, ClassVar, Mapping, Sequence, Self
from copy import deepcopy
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, ClassifierMixin
from pathlib import Path
import joblib


class BaseModel(BaseEstimator, ABC):
    registry: ClassVar[dict[str, type[BaseModel]]] = {}
    model_class: ClassVar[type[Any]]
    params: Mapping[str, Any]
    
    def __init__(self, params: Mapping[str, Any]=dict()) -> None:
        self.params = params

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        BaseModel.registry[cls.__name__] = cls

    @abstractmethod
    def fit(self, X: pd.DataFrame, y: pd.Series, cat_features: Sequence[str] | None = None, eval_set: tuple[pd.DataFrame, pd.Series] | None = None, **kwargs: Any) -> Self:
        raise NotImplemented

    @abstractmethod
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        raise NotImplemented
    
    def save(self, path: str | Path) -> None:
        joblib.dump(self, path)
        
    @classmethod
    def load(cls, path: str | Path) -> Self:
        model = joblib.load(path)
        return model
    
    def clone(self) -> Self:
        return type(self)(params=deepcopy(self.params))

class BaseClassifier(ClassifierMixin, BaseModel):
    classes_: np.ndarray

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        probabilities = self.predict_proba(X)
        return self.classes_[probabilities.argmax(axis=1)]

    @abstractmethod
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        raise NotImplemented


class CatBoostWrapper(BaseClassifier):
    model_class = CatBoostClassifier

    def fit(self, X, y, cat_features=None, eval_set=None, **kwargs):
        self.model_ = self.model_class(**(self.params or {}))
        self.model_.fit(
            X, y,
            cat_features=cat_features,
            eval_set=eval_set,
            **kwargs,
        )
        self.classes_ = np.asarray(self.model_.classes_)
        return self

    def predict_proba(self, X, **kwargs):
        return np.asarray(self.model_.predict_proba(X, **kwargs))


class XGBoostWrapper(BaseClassifier):
    model_class = XGBClassifier

    def fit(self, X, y, cat_features=None, eval_set=None, **kwargs):
        params = dict(self.params or {})

        if cat_features:
            params["enable_categorical"] = True
            params.setdefault("tree_method", "hist")

        self.model_ = self.model_class(**params)
        self.model_.fit(
            X, y,
            eval_set=[eval_set] if eval_set is not None else None,
            **kwargs,
        )
        self.classes_ = np.asarray(self.model_.classes_)
        return self

    def predict_proba(self, X, **kwargs):
        return np.asarray(self.model_.predict_proba(X, **kwargs))

class LightGBMWrapper(BaseClassifier):
    model_class = LGBMClassifier

    def fit(self, X, y, cat_features=None, eval_set=None, **kwargs):
        self.model_ = self.model_class(**(self.params or {}))
        self.model_.fit(
            X, y,
            categorical_feature=(
                cat_features if cat_features is not None else "auto"
            ),
            eval_set=[eval_set] if eval_set is not None else None,
            **kwargs,
        )
        self.classes_ = np.asarray(self.model_.classes_)
        return self

    def predict_proba(self, X, **kwargs):
        return np.asarray(self.model_.predict_proba(X, **kwargs))
