from abc import ABC, abstractmethod
from typing import Any
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
)


class BaseMetric(ABC):
    registry = {}

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseMetric.registry[cls.__name__] = cls

    def __init__(self, **params):
        self.params = params

    @abstractmethod
    def __call__(self, y_true, y_pred) -> Any:
        ...

from dataclasses import dataclass, field


@dataclass
class Evaluator:
    names: list[str]
    params: dict = field(default_factory=dict)

    def __post_init__(self):
        missing = set(self.names) - BaseMetric.registry.keys()
        if missing:
            raise ValueError(f"NotImplemented metrics: {sorted(missing)}")

    def evaluate_metric(self, name, y_true, **inputs):
        metric = BaseMetric.registry[name](**self.params.get(name, {}))
        return metric(y_true, inputs[metric.input_type])

    def evaluate(self, y_true, **inputs):
        return {
            name: self.evaluate_metric(name, y_true, **inputs)
            for name in self.names
        }
        
    def required_input_types(self) -> set[str]:
        return {
            BaseMetric.registry[name](
                **self.params.get(name, {})
            ).input_type
            for name in self.names
        }
        
#########################################################################################################################
class Accuracy(BaseMetric):
    input_type = "labels"

    def __call__(self, y_true, y_pred):
        return float(accuracy_score(y_true, y_pred, **self.params))


class Precision(BaseMetric):
    input_type = "labels"

    def __call__(self, y_true, y_pred):
        return float(precision_score(y_true, y_pred, **self.params))


class Recall(BaseMetric):
    input_type = "labels"

    def __call__(self, y_true, y_pred):
        return float(recall_score(y_true, y_pred, **self.params))


class F1(BaseMetric):
    input_type = "labels"

    def __call__(self, y_true, y_pred):
        return float(f1_score(y_true, y_pred, **self.params))


class RocAuc(BaseMetric):
    input_type = "proba"

    def __call__(self, y_true, y_pred):
        return float(roc_auc_score(y_true, y_pred[:, 1], **self.params))