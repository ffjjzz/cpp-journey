import numpy as np
from collections.abc import Callable, Iterator
import numpy as np
import pandas as pd
from sklearn.model_selection import TimeSeriesSplit
from src.train_tools.trainers import Trainer
from src.train_tools.models import BaseModelClassifier
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    log_loss,
    brier_score_loss,
)


class Evaluator:
    REGISTRY = {
        "roc_auc": roc_auc_score,
        "average_precision": average_precision_score,
        "log_loss": log_loss,
        "brier_score": brier_score_loss,
    }

    def __init__(
        self,
        metrics: list[str],
        metric_params: dict[str, dict] | None = None,
    ) -> None:
        self.metrics = metrics
        self.metric_params = metric_params or {}

    def eval(
        self,
        y_true: np.ndarray,
        y_proba: np.ndarray,
    ) -> dict[str, float]:
        return {
            name: float(
                self.REGISTRY[name](
                    y_true,
                    y_proba,
                    **self.metric_params.get(name, {}),
                )
            )
            for name in self.metrics
        }


class TSValidator:
    def __init__(
        self,
        trainer: Trainer,
        evaluator: Evaluator,
        predict_fn: Callable[
            [BaseModelClassifier, pd.DataFrame], np.ndarray
        ] = lambda model, X: model.predict_proba(X)[:, 1],
        n_splits: int = 5,
        gap: int = 0,
    ) -> None:
        self.trainer = trainer
        self.evaluator = evaluator
        self.predict_fn = predict_fn
        self.n_splits = n_splits
        self.gap = gap

    def split(
        self,
        X: pd.DataFrame,
    ) -> Iterator[tuple[np.ndarray, np.ndarray]]:
        return TimeSeriesSplit(
            n_splits=self.n_splits,
            gap=self.gap,
        ).split(X)

    def run(
        self,
        X: pd.DataFrame,
        y: pd.Series,
    ) -> list:
        results = []

        for fold, (train_idx, valid_idx) in enumerate(self.split(X)):
            fold_model = self.trainer.train(
                X=X.iloc[train_idx],
                y=y.iloc[train_idx],
            )

            y_pred = self.predict_fn(fold_model, X.iloc[valid_idx])
            
            y_true = np.asarray(y.iloc[valid_idx])
            metrics = self.evaluator.eval(y_true, y_pred)

            results.append(metrics)

        return results