from sklearn.metrics import roc_auc_score

from src.train_tools.models import (
    CatBoostClassifierWrapper,
    LGBMClassifierWrapper,
    XGBClassifierWrapper,
)

WRAPPERS = {
    "catboost.CatBoostClassifier": CatBoostClassifierWrapper(), 
    "lightgbm.LGBMClassifier": LGBMClassifierWrapper(),
    "xgboost.XGBClassifier": XGBClassifierWrapper()
}



VAL_METRICS = {
    "auc": lambda model_wrapper, model, X, y: roc_auc_score(y, model_wrapper.predict_proba(model, X)[:, 1]),
    "default": lambda *args, **kwargs: (_ for _ in ()).throw(
            RuntimeError("Used unset metric Check constants.py")
    )
}