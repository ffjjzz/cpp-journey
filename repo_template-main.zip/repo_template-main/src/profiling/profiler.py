import pandas as pd
from pathlib import Path
from src.profiling.tools import psi_evaluate
from conf.pyconfigs import ProfilingDescription, ProcessedDataDesc
import dataframe_image as dfi
from inspect import signature, Parameter



class Profiler:
    def __init__(
        self,
        data: pd.DataFrame,
        time_column: str,
    ) -> None:
        assert time_column in data.columns, "time_column must exist in data"
        assert data[time_column].notna().all(), "time_column contains NaN values"

        self.data = data.sort_values(
            by=[time_column],
            ignore_index=True,
        )

        self.time_column = time_column
        
        
        self.methods = {
            "psi": self.psi_heatmap
        }
        
        self.save_artifact = {
            "psi": self.save_psi_heatmap
        }

    
    def run_profiler(self, profiler_config: ProfilingDescription, data_description: ProcessedDataDesc,  artifacts_path: Path):
        all_params = {
            **profiler_config.params, 
            "cat_features" : data_description.category_columns,
            "numeric_features" : data_description.numeric_columns
            }
        
        for step in profiler_config.steps:
            method = self.methods[step]
            save_method = self.save_artifact[step]
            
            allowed = {
                name
                for name, p in signature(method).parameters.items()
                if p.kind in (Parameter.POSITIONAL_OR_KEYWORD, Parameter.KEYWORD_ONLY)
            }

            filtered = {k: v for k, v in all_params.items() if k in allowed}
            
            result = method(**filtered)
            save_method(result,  artifacts_path)
            
        return artifacts_path


    def psi_heatmap(self, numeric_features: list[str], cat_features: list[str], time_splits_n: int=1):
        psi_dict = psi_evaluate(
            data=self.data,
            time_column=self.time_column,
            time_splits_n=time_splits_n,
            numeric_features=numeric_features,
            cat_features=cat_features
        )
        
        df = pd.DataFrame.from_dict(psi_dict, orient="index")
        # df = df.reindex(
        #     columns=sorted(df.columns, key=lambda x: pd.Timestamp(x[0]))
        # )
        df.columns = df.columns.to_flat_index()
        df.columns = [
            f"{pd.Timestamp(start):%Y-%m-%d} — {pd.Timestamp(end):%Y-%m-%d}"
            for start, end in df.columns.to_flat_index()
        ]
        
        return (
            df.style
            .background_gradient(cmap="Reds", vmin=0, vmax=0.25, axis=None)
            .format("{:.4f}", na_rep="—")
        )
        
    def save_psi_heatmap(self, styler, save_folder: Path) -> Path:
        artifact_path = save_folder / "psi_features.png"
        dfi.export(styler, artifact_path, table_conversion="matplotlib", dpi=200)
        return artifact_path