from __future__ import annotations
import pandas as pd
import numpy as np
from sklearn.model_selection import TimeSeriesSplit
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.axes import Axes
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, ClassVar
from conf.pyconfigs import ProcessedDataDesc
import pandas as pd
from pathlib import Path
import dataframe_image as dfi

@dataclass
class BaseProfiler(ABC):
    registry: ClassVar[dict[str, type[BaseProfiler]]] = {}

    def __init_subclass__(cls, **kw: Any) -> None:
        super().__init_subclass__(**kw)
        BaseProfiler.registry[cls.__name__] = cls
        
    @abstractmethod
    def evaluate(self, X: pd.DataFrame, data_description: ProcessedDataDesc) -> Any: ...

    @abstractmethod
    def save(self, eval_result: Any, save_folder) -> Path: ...


@dataclass
class MainProfiler:
    names: list[str]
    params: dict[str, dict[str, Any]] = field(default_factory=dict)
    steps: list[BaseProfiler] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.steps = [BaseProfiler.registry[n](**self.params.get(n, {})) for n in self.names]

    def run(self, X: pd.DataFrame, data_description: ProcessedDataDesc, save_folder: Path) -> Any: 
        for step in self.steps:
            stats = step.evaluate(X, data_description)
            step.save(stats, save_folder)
        return save_folder
            
    
@dataclass
class PsiProfiler(BaseProfiler):
    time_splits_n: int = 1
    
    def psi_continuous(self,
        reference: pd.Series,
        current: pd.Series
    ) -> float:
        
        edges = np.r_[[np.min([reference.min(), current.min()]) - 1], 
                    np.histogram_bin_edges(reference, bins='doane')[1:-1],
                    [np.max([reference.max(), current.max()]) + 1]]

        ref_pmf, _ = np.histogram(reference.to_numpy(dtype=np.float64), bins=edges)
        cur_pmf, _ = np.histogram(current.to_numpy(dtype=np.float64), bins=edges)

        ref_pmf = np.clip(ref_pmf / len(reference), 1e-6, None)
        cur_pmf = np.clip(cur_pmf / len(current), 1e-6, None)

        return float(np.sum((cur_pmf - ref_pmf) * np.log(cur_pmf / ref_pmf)))

    def psi_categorical(self, reference: pd.Series, current: pd.Series) -> float:
        categories = pd.concat([reference, current]).unique().tolist()
        
        ref_dist = (
            reference.value_counts(normalize=True)
            .reindex(categories, fill_value=0)
            .clip(lower=1e-6)
        )
        
        curr_dist = (
            current.value_counts(normalize=True)
            .reindex(categories, fill_value=0)
            .clip(lower=1e-6)
        )
        return float(np.nansum((curr_dist - ref_dist) * np.log(curr_dist / ref_dist)))
        
    def evaluate(self, X: pd.DataFrame, data_description: ProcessedDataDesc) -> Any: 
        time_column = data_description.time_column
        tscv = TimeSeriesSplit(n_splits=self.time_splits_n)
        splits = list(tscv.split(X))

        base_idx, _ = splits[0]
        baseline = X.iloc[base_idx]
        
        result: dict[str, dict[tuple[object, object], float]] = {
            feature: dict() for feature in data_description.category_columns + data_description.numeric_columns
        }
        
        for _, valid_idx in [(0, base_idx), *splits]:
            current = X.iloc[valid_idx]
            
            start, end = X.iloc[valid_idx[0]][time_column], X.iloc[valid_idx[-1]][time_column]
            period = (start, end)
            

            for feature in data_description.numeric_columns:
                psi_value = self.psi_continuous(
                    reference=baseline[feature],
                    current=current[feature]
                )

                result[feature][period] = psi_value

            for feature in data_description.category_columns:
                psi_value = self.psi_categorical(
                    reference=baseline[feature],
                    current=current[feature],
                )
                result[feature][period] = psi_value

        return result
    
    def psi_heatmap(self, psi_dict: dict):
        df = pd.DataFrame.from_dict(psi_dict, orient="index")

        df = df.reindex(
            columns=sorted(df.columns, key=lambda x: pd.Timestamp(x[0]))
        )
        df.columns = df.columns.to_flat_index()
        df.columns = [
            f"{pd.Timestamp(start):%Y-%m-%d} — {pd.Timestamp(end):%Y-%m-%d}"
            for start, end in df.columns.to_flat_index()
        ]
        return (
            df.style
            .background_gradient(cmap="Reds", vmin=0, vmax=0.25, axis=None)
            .format("{:.4f}", na_rep="—")
        )
    
    def save(self, eval_result: Any, save_folder) -> Path:
        styler = self.psi_heatmap(eval_result)
        artifact_path = save_folder / "psi_features.png"
        dfi.export(styler, artifact_path, table_conversion="matplotlib", dpi=200)#type: ignore
        return artifact_path