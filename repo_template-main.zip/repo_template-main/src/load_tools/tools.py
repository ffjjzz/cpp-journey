import pandas as pd
from teradataml import DataFrame, create_context, fastexport, remove_context

from conf.pyconfigs import DBCredentials, SourceTable


def load_frame(table: SourceTable, database: DBCredentials, output_csv_path: str, open_sessions: int = 4)-> pd.DataFrame:
    try:
        create_context(host=database.host, username=database.username, password=database.password, database=table.database)
        tdf = DataFrame.from_query(f"SELECT * FROM {table.full_name};")
        frame = fastexport(df=tdf, export_to="csv", csv_file=output_csv_path, open_sessions=open_sessions)
        return frame  
    finally:
        remove_context()