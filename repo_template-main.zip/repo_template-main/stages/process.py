from pathlib import Path
from omegaconf import DictConfig
import pandas as pd
import joblib
import hydra

from conf.pyconfigs import (
    Paths,
    MLFlowConfig,
    RawDataDesc,
    ProcessDescription,
    ProcessedDataDesc
)
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from conf.pyconfigs.manifest_tools import parse_load_manifest, save_process_manifest, log_process_mlflow
from src.process_tools.transformers import MainTransformer


def init_defaults(paths_config_path: Path, mlflow_config_path: Path):
    _ = MLFlowConfig.from_yaml(mlflow_config_path)
    paths_config = Paths.from_yaml(paths_config_path)
    return paths_config

def init_process_configs(raw_data_desc_path: Path, process_config_path: Path):
    raw_desc_config = RawDataDesc.from_yaml(raw_data_desc_path)
    process_config = ProcessDescription.from_yaml(process_config_path)
    return raw_desc_config, process_config

def init_manifest(load_manifest_path: Path, process_state_path: Path):
    raw_data_path, mlflow_run_id = parse_load_manifest(load_manifest_path)
    process_state = joblib.load(process_state_path) if process_state_path.is_file() else {}
    return raw_data_path, mlflow_run_id, process_state


@hydra.main(
    version_base=None,
    config_path="../conf",
    config_name="stages/stage_process/process"
)
def main(cfg: DictConfig) -> None:
    stage_params = cfg.stages.stage_process
    process_name = stage_params.process_name
    paths_config_path = stage_params.common_config_paths.paths_config_path
    mlflow_config_path = stage_params.common_config_paths.mlflow_config_path

    paths_config = init_defaults(paths_config_path, mlflow_config_path)


    raw_data_desc_path =  paths_config.config.process / f"{stage_params.raw_data_desc_name}.yaml"
    process_config_path =  paths_config.config.process / f"{stage_params.config_name}.yaml"
        

    raw_desc_config, process_config = init_process_configs(raw_data_desc_path, process_config_path)

    load_manifest_path =  paths_config.manifest.load / f"{stage_params.load_manifest_name}.yaml"
    process_state_path =  paths_config.manifest.process / f"{stage_params.preprocessor_state_name}.joblib"

    raw_data_path, mlflow_run_id, process_state = init_manifest(load_manifest_path, process_state_path)
    
    data = pd.read_csv(raw_data_path)


    if stage_params.fit:
        transformer_params = process_config.fixed_params
        transformer_params["ColumnSelector"] = {"columns": raw_desc_config.get_config_columns()}
    else:
        transformer_params = process_state
        
    mp = MainTransformer(names=process_config.transformers_names, params=transformer_params)
    
    process_state_path = paths_config.manifest.process / f"{stage_params.preprocessor_state_name}.joblib"

    if stage_params.fit:
        mp.fit(data)
        joblib.dump(mp.get_params_state(), process_state_path)
        
    processed = mp.transform(data)
    
    cat_cols = processed.select_dtypes(include="category").columns.tolist()
    numeric_columns = [name for name in raw_desc_config.feature_columns if name not in cat_cols]
    
    
    processed_config = ProcessedDataDesc(
        pi_columns=raw_desc_config.pi_columns,
        time_column=raw_desc_config.time_column,
        target_column=raw_desc_config.target_column,
        numeric_columns=numeric_columns,
        category_columns=cat_cols
        )
    
    
    processed_data_path = paths_config.data.processed / f"{process_name}.csv"
    processed.to_csv(processed_data_path, index=False)
    
    manifest_processed_path = paths_config.manifest.process / f"{process_name}_manifest.yaml"

    save_process_manifest(
        manifest_path=manifest_processed_path,
        processed_config=processed_config,
        process_state_path=process_state_path,
        processed_data_path=processed_data_path,
        mlflow_run_id=mlflow_run_id
        )
    
    log_process_mlflow(mlflow_run_id=mlflow_run_id, process_manifest_path=manifest_processed_path, encode_map_path=process_state_path)
    
if __name__ == "__main__":
    main()