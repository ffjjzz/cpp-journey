from pathlib import Path
import pandas as pd
from conf.pyconfigs import (
    Paths,
    MLFlowConfig,
    ProfilingDescription
)
from conf.pyconfigs.manifest_tools import parse_process_manifest, log_profiling_mlflow
import hydra
from omegaconf import DictConfig
from src.profiling.tools import  MainProfiler

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def init_defaults(paths_config_path: Path, mlflow_config_path: Path):
    _ = MLFlowConfig.from_yaml(mlflow_config_path)
    paths_config = Paths.from_yaml(paths_config_path)
    return paths_config

def init_profiling_configs(profiler_config_path: Path):
    profiler_config = ProfilingDescription.from_yaml(profiler_config_path)
    return profiler_config

def init_manifest(process_manifest_path: Path):
    return parse_process_manifest(process_manifest_path)


@hydra.main(
    version_base=None,
    config_path="../conf",
    config_name="stages/stage_profiling/profile"
)
def main(cfg: DictConfig) -> None:
    stage_params = cfg.stages.stage_profiling

    paths_config_path = stage_params.common_config_paths.paths_config_path
    mlflow_config_path = stage_params.common_config_paths.mlflow_config_path

    paths_config = init_defaults(paths_config_path, mlflow_config_path)

    profiler_config_path = paths_config.config.profiling / f"{stage_params.profiling_config}.yaml"
    profiler_config = init_profiling_configs(profiler_config_path)

    load_manifest_path = paths_config.manifest.process / f"{stage_params.processed_manifest}.yaml"
    data_desc, data_path, mlflow_run_id = init_manifest(load_manifest_path)
    
    data = pd.read_csv(data_path)
    
    mainprofiler = MainProfiler(names=profiler_config.profilers_names, params=profiler_config.params)
    profiling_directory = paths_config.stats.profiling
    mainprofiler.run(data, data_desc, profiling_directory)
    
    log_profiling_mlflow(mlflow_run_id ,profiling_directory)
    

if __name__ == "__main__":
    main()