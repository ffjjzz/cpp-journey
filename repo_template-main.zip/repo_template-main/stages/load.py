import hydra
from omegaconf import DictConfig
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from src.load_tools.tools import load_frame

from conf.pyconfigs import (
    DBCredentials,
    Paths,
    MLFlowExp,
    MLFlowConfig,
    SourceTable
)
from conf.pyconfigs.manifest_tools import save_load_manifest, log_load_mlflow

def init_all_configs(stage_params: DictConfig):
    paths_config_path = stage_params.common_config_paths.paths_config_path
    mlflow_config_path = stage_params.common_config_paths.mlflow_config_path
    database_config_path = stage_params.common_config_paths.database_config_path
    
    db_config = DBCredentials.from_yaml(database_config_path)
    _ = MLFlowConfig.from_yaml(mlflow_config_path)
    paths_config = Paths.from_yaml(paths_config_path)
    
    
    source_table_config_path = paths_config.config.load / f"{stage_params.config_name}.yaml"
    source_config = SourceTable.from_yaml(path=source_table_config_path)
    
    mlflow_exp_config = MLFlowExp.from_name(
        experiment_name=stage_params.mlflow_params.exp_name,
        run_name=stage_params.mlflow_params.run_name
        )
    
    return paths_config, source_config, db_config, mlflow_exp_config



@hydra.main(
    version_base=None,
    config_path="../conf",
    config_name="stages/stage_load/load"
)
def main(cfg: DictConfig) -> None:
    stage_params = cfg.stages.stage_load
    paths_config, source_config, db_config, mlflow_exp_config = init_all_configs(stage_params)

    output_csv_path = paths_config.data.raw / f"{stage_params.raw_name}.csv"
    load_frame(table=source_config, database=db_config, output_csv_path=str(output_csv_path))
    
    manifest_raw_config_path = paths_config.manifest.load / f"{stage_params.raw_name}_manifest.yaml"
    save_load_manifest(
        manifest_path=manifest_raw_config_path,
        raw_data_path=output_csv_path,
        mlflow_run_id=mlflow_exp_config.run_id
        )
    
    log_load_mlflow(mlflow_run_id=mlflow_exp_config.run_id, load_manifest_path=manifest_raw_config_path)


if __name__ == "__main__":
    main()