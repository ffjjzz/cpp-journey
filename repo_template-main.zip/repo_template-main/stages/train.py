from pathlib import Path
import pandas as pd
from omegaconf import DictConfig
import hydra
from conf.pyconfigs import MLFlowConfig, Paths, OptunaTrainConfig, ValidationConfig, TSValidationConfig
from conf.pyconfigs.manifest_tools import parse_process_manifest, log_train_mlflow, save_train_manifest
from src.train_tools.trainers import predict_inputs
from src.train_tools.models import BaseModel
from src.train_tools.metrics import Evaluator
from src.train_tools.trainers import HoldoutValidator, TimeSeriesValidator, MlflowOptunaTrainer
import yaml
import mlflow


import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)



def init_defaults(paths_config_path: Path, mlflow_config_path: Path):
    _ = MLFlowConfig.from_yaml(mlflow_config_path)
    paths_config = Paths.from_yaml(paths_config_path)
    return paths_config

def init_train_configs(train_config_path: Path, validation_config_path: Path):
    train_config = OptunaTrainConfig.from_yaml(train_config_path)
    with open(validation_config_path, encoding="utf-8") as f:
        config = yaml.safe_load(f)
        
    validation_config = ValidationConfig.from_dict(config["metrics"])
    ts_config = TSValidationConfig.from_dict(config["ts_split_params"])
    return train_config, validation_config, ts_config

def init_manifest(process_manifest_path: Path):
    return parse_process_manifest(process_manifest_path)

@hydra.main(
    version_base=None,
    config_path="../conf",
    config_name="stages/stage_train/train"
)
def main(cfg: DictConfig) -> None:
    stage_params = cfg.stages.stage_train

    paths_config_path = stage_params.common_config_paths.paths_config_path
    mlflow_config_path = stage_params.common_config_paths.mlflow_config_path

    paths_config = init_defaults(paths_config_path, mlflow_config_path)


    train_config_path = paths_config.config.train / f"{stage_params.train_config_name}.yaml"
    validation_config_path = paths_config.config.train / f"{stage_params.validatoin_config_name}.yaml"    
    train_config, validation_config, ts_config = init_train_configs(train_config_path, validation_config_path)

    load_manifest_path = paths_config.manifest.process / f"{stage_params.process_manifest_name}.yaml"
    data_desc, data_path, mlflow_run_id = init_manifest(load_manifest_path)
    
    data = pd.read_csv(data_path)
    X, y = data[data_desc.numeric_columns + data_desc.category_columns], data[data_desc.target_column]

    class_name = train_config.model_name
    model = BaseModel.registry[class_name]()
    evaluator = Evaluator(names=validation_config.names, params=validation_config.params)
    holdoutvalidator = HoldoutValidator(evaluator=evaluator)
    ts_validator = TimeSeriesValidator(validator=holdoutvalidator, n_splits=ts_config.n_splits, gap=ts_config.gap)
    optuna_trainer = MlflowOptunaTrainer(validator=ts_validator, config=train_config, mlflow_run_id=mlflow_run_id)
    
    study = optuna_trainer.run(model, X, y, cat_features=data_desc.category_columns)


    train_idx, eval_idx = list(ts_validator.split(X))[-1]

    X_train, y_train = X.iloc[train_idx], y.iloc[train_idx]
    X_eval, y_eval = X.iloc[eval_idx], y.iloc[eval_idx]

    final_model = model.clone()
    final_model.params = {
        **train_config.fixed_params,
        **study.best_params,
    }


    final_model.fit(
        X_train,
        y_train,
        cat_features=data_desc.category_columns,
        eval_set=(X_eval, y_eval),
        **train_config.fit_params,
    )

    final_model_path = paths_config.models / f"{stage_params.train_config_name}.joblib"
    final_model.save(final_model_path)
    log_train_mlflow(mlflow_run_id=optuna_trainer.model_run_id, model_path=final_model_path)

    with mlflow.start_run(run_id=optuna_trainer.model_run_id, nested=True):
        required_input_types = evaluator.required_input_types()
        
        for name, X, y in [("train", X_train, y_train), ("eval", X_eval, y_eval)]:
            
            inputs = predict_inputs(final_model, X, required_input_types)
            
            scores = evaluator.evaluate(y, **inputs)
            mlflow.log_metrics({
                f"{name}/{metric}": float(value)
                for metric, value in scores.items()
            })
            
    train_manifest_path = paths_config.manifest.train / f"{stage_params.train_config_name}_manifest.yaml"
    save_train_manifest(manifest_path=train_manifest_path, model_path=final_model_path, mlflow_run_id=optuna_trainer.model_run_id)


if __name__ == "__main__":
    main()